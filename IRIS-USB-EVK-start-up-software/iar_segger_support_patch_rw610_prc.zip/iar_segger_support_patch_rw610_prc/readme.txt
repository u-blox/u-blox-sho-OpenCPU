  About this patch
   =========================================
   JLink.zip provides the segger script support in JLink.
   arm.zip provides the debugging files in IAR toolchain. 


   MD5SUM:
     081baea0622edd862a8072d25d2d5a4e   arm.zip
     0512deb5557b0ea2b5f0c7b927bb0c48   JLink.zip
   

   How to use this patch
   =========================================
   1.arm.zip

     Please unzip the arm.zip and override the arm folder in your IAR installer path. Don't remove other files in the arm folder!
     For example, C:\Program Files\IAR Systems\Embedded Workbench 9.1\arm.
   
   2.JLink.zip
     a.Please install SEGGER software, which can be downloaded from www.segger.com/jlink-software.html.

     b.Please unzip the JLink.zip and override the JLink folder in your SEGGER installer path. Don't remove other files in the JLink folder!
     For example, C:\Program Files (x86)\SEGGER\JLink.
